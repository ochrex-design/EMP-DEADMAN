-- ModuleScript
-- Put in: ReplicatedStorage > WeaponConfig
-- Shared by the server (damage, ammo, fire rate) and the client (viewmodel look, recoil, ADS).

local WeaponConfig = {}

WeaponConfig.Order = { "Pistol", "Rifle", "Shotgun", "Sniper" } -- keys 1-4

local DARK = Color3.fromRGB(32, 33, 36)
local STEEL = Color3.fromRGB(78, 80, 86)
local TAN = Color3.fromRGB(120, 104, 80)
local METAL, PLASTIC = Enum.Material.Metal, Enum.Material.SmoothPlastic

local function part(name, size, pos, color, material)
	return { Name = name, Size = size, Pos = pos, Color = color, Material = material }
end

WeaponConfig.Weapons = {
	Pistol = {
		Name = "Pistol",
		Damage = 22, HeadshotMultiplier = 2,
		FireRate = 0.18, Auto = false,
		MagSize = 12, ReserveAmmo = 60, ReloadTime = 1.3,
		Range = 300, Spread = 0.5, Pellets = 1,
		Recoil = 1.6, AdsFov = 58,
		HipOffset = Vector3.new(0.5, -0.45, -1.0),
		AdsOffset = Vector3.new(0, -0.2, -0.85),
		Parts = {
			part("Slide", Vector3.new(0.16, 0.2, 0.9), Vector3.new(0, 0.1, -0.35), STEEL, METAL),
			part("Grip", Vector3.new(0.15, 0.42, 0.22), Vector3.new(0, -0.18, 0.02), DARK, PLASTIC),
			part("Sight", Vector3.new(0.05, 0.06, 0.08), Vector3.new(0, 0.22, -0.7), DARK, METAL),
			part("Muzzle", Vector3.new(0.04, 0.04, 0.04), Vector3.new(0, 0.1, -0.82), DARK, METAL),
		},
	},
	Rifle = {
		Name = "Rifle",
		Damage = 24, HeadshotMultiplier = 1.8,
		FireRate = 0.09, Auto = true,
		MagSize = 30, ReserveAmmo = 120, ReloadTime = 1.9,
		Range = 500, Spread = 0.9, Pellets = 1,
		Recoil = 1.1, AdsFov = 50,
		HipOffset = Vector3.new(0.55, -0.5, -1.0),
		AdsOffset = Vector3.new(0, -0.24, -0.85),
		Parts = {
			part("Body", Vector3.new(0.2, 0.3, 1.6), Vector3.new(0, 0, -0.6), DARK, METAL),
			part("Barrel", Vector3.new(0.07, 0.07, 0.9), Vector3.new(0, 0.06, -1.85), STEEL, METAL),
			part("Magazine", Vector3.new(0.12, 0.45, 0.2), Vector3.new(0, -0.35, -0.55), STEEL, METAL),
			part("Stock", Vector3.new(0.15, 0.25, 0.6), Vector3.new(0, -0.02, 0.55), TAN, PLASTIC),
			part("Sight", Vector3.new(0.1, 0.12, 0.22), Vector3.new(0, 0.21, -0.45), DARK, METAL),
			part("Muzzle", Vector3.new(0.04, 0.04, 0.04), Vector3.new(0, 0.06, -2.32), DARK, METAL),
		},
	},
	Shotgun = {
		Name = "Shotgun",
		Damage = 12, HeadshotMultiplier = 1.5,
		FireRate = 0.9, Auto = false,
		MagSize = 6, ReserveAmmo = 30, ReloadTime = 2.4,
		Range = 120, Spread = 4.5, Pellets = 8,
		Recoil = 4.5, AdsFov = 60,
		HipOffset = Vector3.new(0.55, -0.5, -1.0),
		AdsOffset = Vector3.new(0, -0.22, -0.85),
		Parts = {
			part("Body", Vector3.new(0.2, 0.26, 1.2), Vector3.new(0, 0, -0.3), DARK, METAL),
			part("Barrel", Vector3.new(0.12, 0.12, 1.4), Vector3.new(0, 0.05, -1.3), STEEL, METAL),
			part("Pump", Vector3.new(0.22, 0.18, 0.45), Vector3.new(0, -0.14, -1.0), TAN, PLASTIC),
			part("Stock", Vector3.new(0.16, 0.28, 0.7), Vector3.new(0, -0.04, 0.65), TAN, PLASTIC),
			part("Muzzle", Vector3.new(0.04, 0.04, 0.04), Vector3.new(0, 0.05, -2.02), DARK, METAL),
		},
	},
	Sniper = {
		Name = "Sniper",
		Damage = 95, HeadshotMultiplier = 2,
		FireRate = 1.4, Auto = false,
		MagSize = 5, ReserveAmmo = 25, ReloadTime = 2.8,
		Range = 900, Spread = 0.05, Pellets = 1,
		Recoil = 5, AdsFov = 18,
		HipOffset = Vector3.new(0.55, -0.5, -1.0),
		AdsOffset = Vector3.new(0, -0.2, -0.8),
		Parts = {
			part("Body", Vector3.new(0.18, 0.25, 1.4), Vector3.new(0, 0, -0.5), DARK, METAL),
			part("Barrel", Vector3.new(0.06, 0.06, 1.8), Vector3.new(0, 0.05, -1.7), STEEL, METAL),
			part("Scope", Vector3.new(0.14, 0.14, 0.7), Vector3.new(0, 0.27, -0.5), STEEL, METAL),
			part("Stock", Vector3.new(0.15, 0.3, 0.7), Vector3.new(0, -0.03, 0.6), DARK, PLASTIC),
			part("Muzzle", Vector3.new(0.04, 0.04, 0.04), Vector3.new(0, 0.05, -2.62), DARK, METAL),
		},
	},
}

return WeaponConfig
