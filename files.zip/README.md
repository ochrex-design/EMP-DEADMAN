# Roblox multiplayer shooter (Hypershot-style)

A server-authoritative first-person arena shooter: four weapons, headshots, spawn protection, kill feed, leaderboard, and timed rounds (180 s or first to 25 kills). Original code, no copied assets.

## 1. Set up in Roblox Studio

1. Download Roblox Studio and create a new place from the **Baseplate** template.
2. Add each script in the right place, with exactly this name and type:

| File | Type | Location | Name |
|---|---|---|---|
| 1_WeaponConfig.lua | ModuleScript | ReplicatedStorage | `WeaponConfig` |
| 2_GameServer.lua | Script | ServerScriptService | `GameServer` |
| 3_WeaponClient.lua | LocalScript | StarterPlayer > StarterPlayerScripts | `WeaponClient` |
| 4_MapBuilder.lua | Script | ServerScriptService | `MapBuilder` |
| 5_RealisticLighting.lua | Script | ServerScriptService | `RealisticLighting` |

3. Click **Lighting** in the Explorer and set **Technology = Future** in Properties. Scripts can't change this setting.
4. Click **MaterialService** and turn on **Use2022Materials**.

## 2. Test multiplayer

Go to the **Test** tab, set **Clients and Servers** to 2 or more players, and press **Start**. Each window is a separate player.

Controls: WASD move, mouse aim, left click shoot, right click aim down sights, R reload, 1-4 switch weapon.

## 3. Publish so others can play

1. **File > Publish to Roblox** and name your game.
2. Open **Game Settings > Basic Info** and set the game to **Public**.
3. Under **Game Settings > Places**, set **Max Players** (for example 16).

## 4. Making it look realistic

Roblox can get close to realistic, but the biggest gains come from assets, not code:

- **Lighting**: Future technology, atmosphere, bloom and color grading are already set up by `RealisticLighting`.
- **Materials**: use `SurfaceAppearance` with PBR texture maps (color, normal, roughness, metalness) on MeshParts.
- **Map**: replace the generated arena with detailed meshes. Browse the Creator Store (Toolbox) or build in Blender.
- **Guns**: the viewmodels are simple blocks. Swap in MeshPart gun models, keeping a part named `Muzzle` for the flash and tracers.
- **Sound**: add shot, reload and hit sounds to the client script. Use your own audio or Creator Store assets.

## 5. How the shooting is secured

The client only sends its aim direction. The server checks fire rate, ammo and reload state, runs the raycast from the player's head, applies spread and damage, and awards kills. Exploiters can't set their own damage or ammo.

## Ideas to add next

Teams, a shop with weapon skins, DataStore saving for stats, ranked matches, and a weapon-selection menu.
