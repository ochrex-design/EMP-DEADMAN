-- Script (server)
-- Put in: ServerScriptService > GameServer
-- The server decides every hit. Clients only send "I fired in this direction".

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local WeaponConfig = require(ReplicatedStorage:WaitForChild("WeaponConfig"))

local ROUND_TIME = 180 -- seconds
local INTERMISSION = 10 -- seconds
local KILL_LIMIT = 25 -- round ends early when someone reaches this

Players.RespawnTime = 3

-- Remotes ------------------------------------------------------------------
local Remotes = Instance.new("Folder")
Remotes.Name = "Remotes"
Remotes.Parent = ReplicatedStorage

local function makeRemote(name)
	local r = Instance.new("RemoteEvent")
	r.Name = name
	r.Parent = Remotes
	return r
end

local FireRemote = makeRemote("Fire") -- client -> server
local ReloadRemote = makeRemote("Reload") -- client -> server
local EquipRemote = makeRemote("Equip") -- client -> server
local AmmoRemote = makeRemote("Ammo") -- server -> client
local HitRemote = makeRemote("HitMarker") -- server -> client
local TracerRemote = makeRemote("Tracer") -- server -> all clients
local KillFeedRemote = makeRemote("KillFeed") -- server -> all clients
local RoundRemote = makeRemote("Round") -- server -> all clients

-- Per-player state -----------------------------------------------------------
local states = {}

local function newState()
	local ammo = {}
	for name, cfg in pairs(WeaponConfig.Weapons) do
		ammo[name] = { mag = cfg.MagSize, reserve = cfg.ReserveAmmo }
	end
	return { weapon = "Rifle", ammo = ammo, nextFire = 0, reloadingUntil = 0, reloadToken = 0 }
end

local function sendAmmo(player)
	local state = states[player]
	if not state then return end
	local a = state.ammo[state.weapon]
	AmmoRemote:FireClient(player, state.weapon, a.mag, a.reserve)
end

local function applySpread(direction, spreadDeg)
	if spreadDeg <= 0 then return direction end
	local angle = math.random() * math.pi * 2
	local radius = math.sqrt(math.random()) * math.tan(math.rad(spreadDeg))
	local cf = CFrame.lookAt(Vector3.zero, direction)
	local offset = cf.RightVector * math.cos(angle) * radius + cf.UpVector * math.sin(angle) * radius
	return (direction + offset).Unit
end

-- Player setup ---------------------------------------------------------------
local function setupPlayer(player)
	local ls = Instance.new("Folder")
	ls.Name = "leaderstats"
	ls.Parent = player
	for _, statName in ipairs({ "Kills", "Deaths" }) do
		local v = Instance.new("IntValue")
		v.Name = statName
		v.Parent = ls
	end

	states[player] = newState()

	player.CharacterAdded:Connect(function(char)
		states[player] = newState()
		local hum = char:WaitForChild("Humanoid")
		hum.Died:Connect(function()
			ls.Deaths.Value += 1
			local attackerId = hum:GetAttribute("LastAttacker")
			local attacker = attackerId and Players:GetPlayerByUserId(attackerId)
			if attacker and attacker ~= player then
				local attackerLs = attacker:FindFirstChild("leaderstats")
				if attackerLs then attackerLs.Kills.Value += 1 end
				KillFeedRemote:FireAllClients(attacker.Name, player.Name, hum:GetAttribute("LastWeapon") or "")
			else
				KillFeedRemote:FireAllClients("", player.Name, "")
			end
		end)
	end)
end

Players.PlayerAdded:Connect(setupPlayer)
for _, p in ipairs(Players:GetPlayers()) do setupPlayer(p) end
Players.PlayerRemoving:Connect(function(p) states[p] = nil end)

-- Shooting -------------------------------------------------------------------
FireRemote.OnServerEvent:Connect(function(player, direction)
	local state = states[player]
	local char = player.Character
	if not state or not char then return end
	if typeof(direction) ~= "Vector3" then return end
	if not (direction.Magnitude > 0.9 and direction.Magnitude < 1.1) then return end -- also rejects NaN

	local hum = char:FindFirstChildOfClass("Humanoid")
	local head = char:FindFirstChild("Head")
	if not hum or hum.Health <= 0 or not head then return end

	local cfg = WeaponConfig.Weapons[state.weapon]
	local now = os.clock()
	if now < state.reloadingUntil then return end
	if now < state.nextFire - 0.03 then return end -- small tolerance for network jitter

	local ammo = state.ammo[state.weapon]
	if ammo.mag <= 0 then return end

	state.nextFire = now + cfg.FireRate
	ammo.mag -= 1

	local origin = head.Position
	direction = direction.Unit

	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { char }

	local endpoints = {}
	for _ = 1, cfg.Pellets do
		local dir = applySpread(direction, cfg.Spread)
		local result = workspace:Raycast(origin, dir * cfg.Range, params)
		table.insert(endpoints, result and result.Position or (origin + dir * cfg.Range))

		if result then
			local hitModel = result.Instance:FindFirstAncestorOfClass("Model")
			local targetHum = hitModel and hitModel:FindFirstChildOfClass("Humanoid")
			if targetHum and targetHum.Health > 0 then
				local damage = cfg.Damage
				local headshot = result.Instance.Name == "Head"
				if headshot then damage *= cfg.HeadshotMultiplier end

				targetHum:SetAttribute("LastAttacker", player.UserId)
				targetHum:SetAttribute("LastWeapon", state.weapon)
				targetHum:TakeDamage(damage) -- respects spawn ForceField
				HitRemote:FireClient(player, headshot, targetHum.Health <= 0)
			end
		end
	end

	TracerRemote:FireAllClients(player, origin, endpoints)
	AmmoRemote:FireClient(player, state.weapon, ammo.mag, ammo.reserve)
end)

ReloadRemote.OnServerEvent:Connect(function(player)
	local state = states[player]
	if not state then return end
	local cfg = WeaponConfig.Weapons[state.weapon]
	local ammo = state.ammo[state.weapon]
	local now = os.clock()
	if now < state.reloadingUntil or ammo.mag >= cfg.MagSize or ammo.reserve <= 0 then return end

	state.reloadingUntil = now + cfg.ReloadTime
	state.reloadToken += 1
	local token = state.reloadToken

	task.delay(cfg.ReloadTime, function()
		if states[player] ~= state or state.reloadToken ~= token then return end -- cancelled (switched weapon / died)
		local taken = math.min(cfg.MagSize - ammo.mag, ammo.reserve)
		ammo.mag += taken
		ammo.reserve -= taken
		sendAmmo(player)
	end)
end)

EquipRemote.OnServerEvent:Connect(function(player, weaponName)
	local state = states[player]
	if not state or typeof(weaponName) ~= "string" or not WeaponConfig.Weapons[weaponName] then return end
	state.weapon = weaponName
	state.reloadToken += 1 -- cancels any reload in progress
	state.reloadingUntil = 0
	state.nextFire = math.max(state.nextFire, os.clock() + 0.3) -- equip delay stops swap-fire exploits
	sendAmmo(player)
end)

-- Rounds ---------------------------------------------------------------------
local function getLeader()
	local topKills, topPlayer = 0, nil
	for _, p in ipairs(Players:GetPlayers()) do
		local ls = p:FindFirstChild("leaderstats")
		local k = ls and ls.Kills.Value or 0
		if k > topKills then topKills, topPlayer = k, p end
	end
	return topPlayer, topKills
end

local function resetMatch()
	for _, p in ipairs(Players:GetPlayers()) do
		local ls = p:FindFirstChild("leaderstats")
		if ls then
			ls.Kills.Value = 0
			ls.Deaths.Value = 0
		end
		p:LoadCharacter()
	end
end

task.spawn(function()
	while true do
		for t = INTERMISSION, 1, -1 do
			RoundRemote:FireAllClients("Intermission", t)
			task.wait(1)
		end

		resetMatch()

		for t = ROUND_TIME, 1, -1 do
			RoundRemote:FireAllClients("Round", t)
			task.wait(1)
			local _, kills = getLeader()
			if kills >= KILL_LIMIT then break end
		end

		local winner, kills = getLeader()
		RoundRemote:FireAllClients("Winner", winner and winner.Name or "Nobody", kills)
		task.wait(6)
	end
end)
