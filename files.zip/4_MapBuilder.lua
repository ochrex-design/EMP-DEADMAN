-- Script (server)
-- Put in: ServerScriptService > MapBuilder
-- Builds a simple concrete arena with cover, lamps and spawn points so you can playtest right away.
-- Later, replace it with your own detailed map and delete this script.

local rng = Random.new(7)

for _, name in ipairs({ "Baseplate", "SpawnLocation" }) do
	local old = workspace:FindFirstChild(name)
	if old then old:Destroy() end
end

local map = Instance.new("Folder")
map.Name = "Arena"
map.Parent = workspace

local function block(name, size, cframe, color, material)
	local p = Instance.new("Part")
	p.Name = name
	p.Size = size
	p.CFrame = cframe
	p.Color = color
	p.Material = material
	p.Anchored = true
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	p.Parent = map
	return p
end

-- Floor and perimeter walls
block("Floor", Vector3.new(240, 2, 240), CFrame.new(0, -1, 0), Color3.fromRGB(112, 112, 114), Enum.Material.Concrete)
local wallColor = Color3.fromRGB(128, 92, 78)
block("WallN", Vector3.new(240, 26, 4), CFrame.new(0, 13, -120), wallColor, Enum.Material.Brick)
block("WallS", Vector3.new(240, 26, 4), CFrame.new(0, 13, 120), wallColor, Enum.Material.Brick)
block("WallE", Vector3.new(4, 26, 240), CFrame.new(120, 13, 0), wallColor, Enum.Material.Brick)
block("WallW", Vector3.new(4, 26, 240), CFrame.new(-120, 13, 0), wallColor, Enum.Material.Brick)

-- Cover: crates, containers and low walls
local coverStyles = {
	{ Enum.Material.WoodPlanks, Color3.fromRGB(139, 105, 70) },
	{ Enum.Material.DiamondPlate, Color3.fromRGB(95, 100, 108) },
	{ Enum.Material.Concrete, Color3.fromRGB(150, 150, 148) },
	{ Enum.Material.CorrodedMetal, Color3.fromRGB(120, 70, 52) },
}
for i = 1, 34 do
	local style = coverStyles[rng:NextInteger(1, #coverStyles)]
	local size = Vector3.new(rng:NextNumber(5, 14), rng:NextNumber(4, 10), rng:NextNumber(5, 14))
	local pos = Vector3.new(rng:NextNumber(-75, 75), size.Y / 2, rng:NextNumber(-75, 75))
	block("Cover" .. i, size, CFrame.new(pos) * CFrame.Angles(0, rng:NextNumber(0, math.pi), 0), style[2], style[1])
end

-- Lamp posts (warm light looks great with Future lighting)
for i = 1, 8 do
	local a = (i / 8) * math.pi * 2 + 0.4
	local x, z = math.cos(a) * 105, math.sin(a) * 105
	block("Pole" .. i, Vector3.new(1, 18, 1), CFrame.new(x, 9, z), Color3.fromRGB(40, 40, 44), Enum.Material.Metal)
	local bulb = block("Bulb" .. i, Vector3.new(2.5, 1, 2.5), CFrame.new(x, 18.5, z), Color3.fromRGB(255, 214, 160), Enum.Material.Neon)
	local light = Instance.new("PointLight")
	light.Range = 45
	light.Brightness = 2.2
	light.Color = Color3.fromRGB(255, 205, 150)
	light.Shadows = true
	light.Parent = bulb
end

-- Spawn points in a ring
for i = 1, 8 do
	local a = (i / 8) * math.pi * 2
	local s = Instance.new("SpawnLocation")
	s.Name = "Spawn" .. i
	s.Anchored = true
	s.Size = Vector3.new(6, 1, 6)
	s.Position = Vector3.new(math.cos(a) * 90, 0.5, math.sin(a) * 90)
	s.Neutral = true
	s.Duration = 3 -- seconds of spawn protection (ForceField)
	s.Transparency = 1
	s.CanCollide = false
	for _, child in ipairs(s:GetChildren()) do
		if child:IsA("Decal") then child:Destroy() end
	end
	s.Parent = map
end
