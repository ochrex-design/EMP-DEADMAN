-- Script (server)
-- Put in: ServerScriptService > RealisticLighting
--
-- IMPORTANT: set Lighting > Technology = Future in Studio yourself.
-- Roblox does not allow scripts to change that property.

local Lighting = game:GetService("Lighting")

-- Clear any existing effects so settings don't stack
for _, child in ipairs(Lighting:GetChildren()) do
	if child:IsA("PostEffect") or child:IsA("Atmosphere") or child:IsA("Sky") then
		child:Destroy()
	end
end

-- Late-afternoon sun: long, soft shadows
Lighting.ClockTime = 16.2
Lighting.GeographicLatitude = 35
Lighting.Brightness = 3
Lighting.ExposureCompensation = 0.25
Lighting.GlobalShadows = true
Lighting.ShadowSoftness = 0.2
Lighting.EnvironmentDiffuseScale = 1
Lighting.EnvironmentSpecularScale = 1
Lighting.Ambient = Color3.fromRGB(30, 32, 38)
Lighting.OutdoorAmbient = Color3.fromRGB(70, 75, 85)

local function add(class, props)
	local inst = Instance.new(class)
	for k, v in pairs(props) do inst[k] = v end
	inst.Parent = Lighting
	return inst
end

add("Sky", {})

add("Atmosphere", {
	Density = 0.32,
	Offset = 0.25,
	Color = Color3.fromRGB(199, 170, 150),
	Decay = Color3.fromRGB(106, 112, 125),
	Glare = 0.4,
	Haze = 1.6,
})

add("BloomEffect", { Intensity = 0.35, Size = 24, Threshold = 1 })

add("ColorCorrectionEffect", {
	Brightness = 0,
	Contrast = 0.12,
	Saturation = -0.05,
	TintColor = Color3.fromRGB(255, 247, 238),
})

add("SunRaysEffect", { Intensity = 0.08, Spread = 0.6 })

-- Very mild depth of field; raise FarIntensity for a more cinematic look
add("DepthOfFieldEffect", { FarIntensity = 0.08, FocusDistance = 90, InFocusRadius = 70, NearIntensity = 0 })
