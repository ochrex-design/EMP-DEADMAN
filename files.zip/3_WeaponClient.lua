-- LocalScript
-- Put in: StarterPlayer > StarterPlayerScripts > WeaponClient
-- First-person camera, procedural gun viewmodel, recoil, aim-down-sights, HUD, kill feed.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local Debris = game:GetService("Debris")

local player = Players.LocalPlayer
local camera = workspace.CurrentCamera
local WeaponConfig = require(ReplicatedStorage:WaitForChild("WeaponConfig"))
local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local FireRemote = Remotes:WaitForChild("Fire")
local ReloadRemote = Remotes:WaitForChild("Reload")
local EquipRemote = Remotes:WaitForChild("Equip")
local AmmoRemote = Remotes:WaitForChild("Ammo")
local HitRemote = Remotes:WaitForChild("HitMarker")
local TracerRemote = Remotes:WaitForChild("Tracer")
local KillFeedRemote = Remotes:WaitForChild("KillFeed")
local RoundRemote = Remotes:WaitForChild("Round")

local VIEW_SCALE = 0.55
local BASE_FOV = 70

player.CameraMode = Enum.CameraMode.LockFirstPerson
UserInputService.MouseIconEnabled = false

-- State ----------------------------------------------------------------------
local currentName = "Rifle"
local ammo = {}
local mouseDown, aiming = false, false
local nextFire, reloadingUntil = 0, 0
local recoilPitch, recoilYaw, adsAlpha = 0, 0, 0
local swayX, swayY, bobTime = 0, 0, 0
local viewmodel, muzzle, muzzleLight
local character, humanoid

local function resetAmmo()
	for name, cfg in pairs(WeaponConfig.Weapons) do
		ammo[name] = { mag = cfg.MagSize, reserve = cfg.ReserveAmmo }
	end
end
resetAmmo()

-- HUD ------------------------------------------------------------------------
local function make(class, props, parent)
	local inst = Instance.new(class)
	for k, v in pairs(props) do inst[k] = v end
	inst.Parent = parent
	return inst
end

local function text(props, parent)
	props.BackgroundTransparency = 1
	props.Font = Enum.Font.GothamBold
	props.TextColor3 = props.TextColor3 or Color3.new(1, 1, 1)
	props.TextStrokeTransparency = 0.5
	return make("TextLabel", props, parent)
end

local gui = make("ScreenGui", { Name = "ShooterHUD", ResetOnSpawn = false, IgnoreGuiInset = true }, player:WaitForChild("PlayerGui"))

local crosshair = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5),
	Size = UDim2.fromOffset(0, 0), BackgroundTransparency = 1,
}, gui)
for _, r in ipairs({ { -1, -14, 2, 8 }, { -1, 6, 2, 8 }, { -14, -1, 8, 2 }, { 6, -1, 8, 2 } }) do
	make("Frame", {
		Position = UDim2.fromOffset(r[1], r[2]), Size = UDim2.fromOffset(r[3], r[4]),
		BackgroundColor3 = Color3.new(1, 1, 1), BorderSizePixel = 0,
	}, crosshair)
end

local hitMarker = make("Frame", {
	AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5),
	Size = UDim2.fromOffset(0, 0), BackgroundTransparency = 1, Visible = false,
}, gui)
for _, rot in ipairs({ 45, -45 }) do
	make("Frame", {
		AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.fromOffset(20, 2), Rotation = rot,
		BackgroundColor3 = Color3.new(1, 1, 1), BorderSizePixel = 0,
	}, hitMarker)
end

local ammoLabel = text({
	AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -30, 1, -30),
	Size = UDim2.fromOffset(260, 56), TextSize = 46, TextXAlignment = Enum.TextXAlignment.Right,
}, gui)
local weaponLabel = text({
	AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -30, 1, -86),
	Size = UDim2.fromOffset(260, 28), TextSize = 20, TextXAlignment = Enum.TextXAlignment.Right,
}, gui)

local healthBack = make("Frame", {
	AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 30, 1, -30), Size = UDim2.fromOffset(280, 14),
	BackgroundColor3 = Color3.fromRGB(20, 20, 24), BackgroundTransparency = 0.3, BorderSizePixel = 0,
}, gui)
local healthFill = make("Frame", {
	Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.fromRGB(110, 200, 120), BorderSizePixel = 0,
}, healthBack)

local timerLabel = text({
	AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 16),
	Size = UDim2.fromOffset(320, 34), TextSize = 26,
}, gui)
local banner = text({
	AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 56),
	Size = UDim2.fromOffset(640, 40), TextSize = 30,
}, gui)

local killFeed = make("Frame", {
	AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -20, 0, 20),
	Size = UDim2.fromOffset(380, 200), BackgroundTransparency = 1,
}, gui)
make("UIListLayout", { HorizontalAlignment = Enum.HorizontalAlignment.Right, SortOrder = Enum.SortOrder.LayoutOrder, Padding = UDim.new(0, 2) }, killFeed)

local function updateAmmoText()
	local cfg = WeaponConfig.Weapons[currentName]
	local a = ammo[currentName]
	weaponLabel.Text = os.clock() < reloadingUntil and (cfg.Name .. " - reloading") or cfg.Name
	ammoLabel.Text = string.format("%d / %d", a.mag, a.reserve)
end

local function showHitMarker(headshot, kill)
	local color = kill and Color3.fromRGB(255, 70, 70) or (headshot and Color3.fromRGB(255, 210, 80) or Color3.new(1, 1, 1))
	for _, f in ipairs(hitMarker:GetChildren()) do f.BackgroundColor3 = color end
	hitMarker.Visible = true
	task.delay(0.12, function() hitMarker.Visible = false end)
end

-- Viewmodel ------------------------------------------------------------------
local function buildViewmodel(name)
	if viewmodel then viewmodel:Destroy() end
	local cfg = WeaponConfig.Weapons[name]

	local model = Instance.new("Model")
	model.Name = "Viewmodel"
	local root = Instance.new("Part")
	root.Name = "Root"
	root.Size = Vector3.new(0.1, 0.1, 0.1)
	root.Transparency = 1
	root.Anchored = true
	root.CanCollide, root.CanQuery, root.CanTouch = false, false, false
	root.Parent = model
	model.PrimaryPart = root

	for _, spec in ipairs(cfg.Parts) do
		local p = Instance.new("Part")
		p.Name = spec.Name
		p.Size = spec.Size * VIEW_SCALE
		p.CFrame = CFrame.new(spec.Pos * VIEW_SCALE)
		p.Color = spec.Color
		p.Material = spec.Material
		p.Anchored = true
		p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = false, false, false, false
		if spec.Name == "Muzzle" then
			p.Transparency = 1
			muzzle = p
			muzzleLight = make("PointLight", { Color = Color3.fromRGB(255, 190, 110), Range = 12, Brightness = 4, Enabled = false }, p)
		end
		p.Parent = model
	end

	viewmodel = model
	model.Parent = camera
end

local function flash()
	if not muzzleLight then return end
	muzzleLight.Enabled = true
	task.delay(0.04, function() if muzzleLight then muzzleLight.Enabled = false end end)
end

local function drawTracer(from, to)
	local dist = (to - from).Magnitude
	if dist < 1 then return end
	local p = Instance.new("Part")
	p.Anchored = true
	p.CanCollide, p.CanQuery, p.CanTouch, p.CastShadow = false, false, false, false
	p.Material = Enum.Material.Neon
	p.Color = Color3.fromRGB(255, 214, 140)
	p.Size = Vector3.new(0.05, 0.05, dist)
	p.CFrame = CFrame.lookAt(from, to) * CFrame.new(0, 0, -dist / 2)
	p.Parent = workspace
	TweenService:Create(p, TweenInfo.new(0.12), { Transparency = 1 }):Play()
	Debris:AddItem(p, 0.15)
end

-- Actions --------------------------------------------------------------------
local function reload()
	local cfg = WeaponConfig.Weapons[currentName]
	local a = ammo[currentName]
	if os.clock() < reloadingUntil or a.mag >= cfg.MagSize or a.reserve <= 0 then return end
	reloadingUntil = os.clock() + cfg.ReloadTime
	ReloadRemote:FireServer()
	updateAmmoText()
	task.delay(cfg.ReloadTime + 0.1, updateAmmoText)
end

local function tryFire(now)
	local cfg = WeaponConfig.Weapons[currentName]
	local a = ammo[currentName]
	if now < nextFire or now < reloadingUntil then return end
	if a.mag <= 0 then
		reload()
		return
	end

	nextFire = now + cfg.FireRate
	a.mag -= 1

	local dir = camera.CFrame.LookVector
	FireRemote:FireServer(dir)

	-- local tracer so your own shot feels instant
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { character, viewmodel }
	local result = workspace:Raycast(camera.CFrame.Position, dir * cfg.Range, params)
	local endPos = result and result.Position or (camera.CFrame.Position + dir * cfg.Range)
	if muzzle then drawTracer(muzzle.Position, endPos) end

	recoilPitch += math.rad(cfg.Recoil)
	recoilYaw += math.rad((math.random() - 0.5) * cfg.Recoil * 0.6)
	flash()
	updateAmmoText()
	if not cfg.Auto then mouseDown = false end -- one shot per click for semi-auto guns
end

local function equip(name)
	if name == currentName and viewmodel then return end
	currentName = name
	reloadingUntil = 0
	buildViewmodel(name)
	EquipRemote:FireServer(name)
	updateAmmoText()
end

-- Input ----------------------------------------------------------------------
local KEY_SLOTS = {
	[Enum.KeyCode.One] = 1, [Enum.KeyCode.Two] = 2, [Enum.KeyCode.Three] = 3, [Enum.KeyCode.Four] = 4,
}

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then return end
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		mouseDown = true
	elseif input.UserInputType == Enum.UserInputType.MouseButton2 then
		aiming = true
		UserInputService.MouseDeltaSensitivity = 0.5
	elseif input.UserInputType == Enum.UserInputType.Keyboard then
		if input.KeyCode == Enum.KeyCode.R then
			reload()
		elseif KEY_SLOTS[input.KeyCode] then
			equip(WeaponConfig.Order[KEY_SLOTS[input.KeyCode]])
		end
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		mouseDown = false
	elseif input.UserInputType == Enum.UserInputType.MouseButton2 then
		aiming = false
		UserInputService.MouseDeltaSensitivity = 1
	end
end)

-- Server events --------------------------------------------------------------
AmmoRemote.OnClientEvent:Connect(function(weapon, mag, reserve)
	ammo[weapon] = { mag = mag, reserve = reserve }
	if weapon == currentName then updateAmmoText() end
end)

HitRemote.OnClientEvent:Connect(showHitMarker)

TracerRemote.OnClientEvent:Connect(function(shooter, origin, endpoints)
	if shooter == player then return end
	for _, endpoint in ipairs(endpoints) do drawTracer(origin, endpoint) end
end)

KillFeedRemote.OnClientEvent:Connect(function(killer, victim, weapon)
	local msg = killer ~= "" and string.format("%s  [%s]  %s", killer, weapon, victim) or (victim .. " died")
	local entry = text({
		Size = UDim2.new(1, 0, 0, 22), TextSize = 16, Text = msg, TextXAlignment = Enum.TextXAlignment.Right,
		TextColor3 = (killer == player.Name) and Color3.fromRGB(255, 210, 80) or Color3.new(1, 1, 1),
	}, killFeed)
	Debris:AddItem(entry, 5)
end)

local bannerToken = 0
RoundRemote.OnClientEvent:Connect(function(phase, a, b)
	if phase == "Intermission" then
		timerLabel.Text = "Next round in " .. a
	elseif phase == "Round" then
		timerLabel.Text = string.format("%d:%02d", a // 60, a % 60)
	elseif phase == "Winner" then
		timerLabel.Text = ""
		banner.Text = string.format("%s wins with %d kills", a, b)
		bannerToken += 1
		local token = bannerToken
		task.delay(5, function() if bannerToken == token then banner.Text = "" end end)
	end
end)

-- Character ------------------------------------------------------------------
local function onCharacter(char)
	character = char
	humanoid = char:WaitForChild("Humanoid")
	resetAmmo()
	currentName = "Rifle"
	reloadingUntil = 0
	local function updateHealth()
		healthFill.Size = UDim2.fromScale(math.clamp(humanoid.Health / humanoid.MaxHealth, 0, 1), 1)
	end
	humanoid.HealthChanged:Connect(updateHealth)
	updateHealth()
	buildViewmodel(currentName)
	EquipRemote:FireServer(currentName)
	updateAmmoText()
end
player.CharacterAdded:Connect(onCharacter)
if player.Character then task.spawn(onCharacter, player.Character) end

-- Per-frame step (runs right after Roblox's own camera) -----------------------
RunService:BindToRenderStep("WeaponStep", Enum.RenderPriority.Camera.Value + 1, function(dt)
	if not viewmodel or not humanoid or not character then return end
	local alive = humanoid.Health > 0
	viewmodel.Parent = alive and camera or nil
	if not alive then return end

	local cfg = WeaponConfig.Weapons[currentName]
	local now = os.clock()
	local k = math.min(1, dt * 12)

	-- recoil: a visual offset on top of the normal camera, so the view settles back by itself
	recoilPitch *= math.max(0, 1 - dt * 6)
	recoilYaw *= math.max(0, 1 - dt * 6)
	camera.CFrame *= CFrame.Angles(recoilPitch, recoilYaw, 0)

	-- aim down sights
	adsAlpha += ((aiming and 1 or 0) - adsAlpha) * k
	camera.FieldOfView += ((aiming and cfg.AdsFov or BASE_FOV) - camera.FieldOfView) * k
	crosshair.Visible = adsAlpha < 0.3

	-- hide the default first-person arms (the viewmodel replaces them)
	for _, part in ipairs(character:GetChildren()) do
		if part:IsA("BasePart") and (part.Name:find("Arm") or part.Name:find("Hand")) then
			part.LocalTransparencyModifier = 1
		end
	end

	if mouseDown then tryFire(now) end

	-- viewmodel sway, walk bob, reload dip
	local delta = UserInputService:GetMouseDelta()
	swayX += (-delta.X * 0.002 - swayX) * k
	swayY += (delta.Y * 0.002 - swayY) * k

	local hrp = character:FindFirstChild("HumanoidRootPart")
	local v = hrp and hrp.AssemblyLinearVelocity or Vector3.zero
	bobTime += dt * Vector3.new(v.X, 0, v.Z).Magnitude * 0.5
	local bob = 1 - adsAlpha * 0.85

	local dip = 0
	if now < reloadingUntil then
		dip = math.sin((1 - (reloadingUntil - now) / cfg.ReloadTime) * math.pi)
	end

	local offset = cfg.HipOffset:Lerp(cfg.AdsOffset, adsAlpha)
	local pose = CFrame.new(
		offset.X + swayX + math.sin(bobTime) * 0.012 * bob,
		offset.Y + swayY + math.abs(math.cos(bobTime)) * 0.01 * bob - dip * 0.3,
		offset.Z + recoilPitch * 6
	) * CFrame.Angles(recoilPitch * 6 + dip * 0.5, 0, dip * 0.4)

	viewmodel:PivotTo(camera.CFrame * pose)
end)
